TM1638
======

Controlling TM1638 modules with Arduino

Connecting the TM1638 to Arduino:

<pre>
Arduino              TM1638 based board
3.3V   ------------------ VCC
GND    ------------------ GND
PIN #7 ------------------ STB
PIN #8 ------------------ DIO
PIN #9 ------------------ CLK
</pre>

Blog post: http://blog.3d-logic.com/2015/01/10/using-a-tm1638-based-board-with-arduino/

Video: https://www.youtube.com/watch?v=b8O9RTXvbNQ
